/* Features: colour swatches, calculator, gallery, services booking, dealer finder, login and dashboards.
   Shade list (C) and calculator rates (PR) live here. */
/* platform features */
const store={sv:[],hist:[],leads:[],books:[]};
try{store.sv=JSON.parse(localStorage.getItem("av_sv")||"[]")}catch(e){}
const C=[["Sunset Coral","AR101","#ff6b5e"],["Mango Zest","AR102","#ffb800"],["Lime Pop","AR103","#8bd450"],["Lagoon","AR104","#0fb5a2"],["Sky Splash","AR105","#2d9cff"],["Royal Violet","AR106","#6c4cf5"],["Orchid","AR107","#ff4fa3"],["Terracotta","AR108","#c8623f"],["Sand Dune","AR109","#e3cfa8"],["Mist Grey","AR110","#b9bfcc"],["Midnight","AR111","#26305a"],["Pearl White","AR112","#f4efe6"],["Olive Grove","AR113","#8a8f3a"],["Peach Cream","AR114","#ffd2b3"],["Ocean Teal","AR115","#1e7f8c"],["Berry Wine","AR116","#8e2a54"]];
const save=()=>{try{localStorage.setItem("av_sv",JSON.stringify(store.sv))}catch(e){}};
function lead(t,m){store.leads.push({t,m,s:"New",d:new Date().toLocaleDateString()});window.open(wa(m),"_blank","noopener")}
function rot(hex,d){let[r,g,b]=[1,3,5].map(i=>parseInt(hex.substr(i,2),16)/255),M=Math.max(r,g,b),m=Math.min(r,g,b),l=(M+m)/2,s=M==m?0:(M-m)/(1-Math.abs(2*l-1)),h=M==m?0:M==r?((g-b)/(M-m)+6)%6:M==g?(b-r)/(M-m)+2:(r-g)/(M-m)+4;h=(h*60+d)%360;const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1)))).toString(16).padStart(2,"0")};return"#"+f(0)+f(8)+f(4)}
let cn="";
let curHex="#6c4cf5";function paint(hex,name){curHex=hex;cn=name;$("#cn").textContent=name;$("#cn2").textContent=name;try{autoWall()}catch(e){}$("#gw").innerHTML=[30,180,330].map(d=>{const x=rot(hex,d);return '<button class="dot" data-x="'+x+'" style="background:'+x+'" aria-label="Try '+x+'"></button>'}).join(" ")}
function drawSw(){const q=$("#q").value.toLowerCase();$("#sw").innerHTML=C.map((c,i)=>(c[0]+c[1]).toLowerCase().includes(q)?'<div><button class="c" data-c="'+i+'" style="background:'+c[2]+'" aria-label="Apply '+c[0]+'"></button><button class="h" data-h="'+i+'" aria-label="Save '+c[0]+'">'+(store.sv.includes(c[1])?"♥":"♡")+'</button><small>'+c[0]+'<br>'+c[1]+'</small></div>':"").join("")}
$("#q").oninput=drawSw;$("#cmp").oninput=e=>$("#cr").setAttribute("width",e.target.value*6);
$("#shr").onclick=()=>{const t="My Areva Paints palette: "+(store.sv.map(k=>C.find(c=>c[0]&&c[1]===k)[0]).join(", ")||cn);navigator.share?navigator.share({text:t}).catch(()=>{}):navigator.clipboard&&navigator.clipboard.writeText(t)};
const PR=[["Interior emulsion",120,420],["Exterior emulsion",100,520],["Waterproofing coat",60,650],["Primer",140,300]];
$("#cp").innerHTML=PR.map((p,i)=>"<option value="+i+">"+p[0]+"</option>").join("");
function rc(){const v=s=>+$(s).value||0,p=PR[v("#cp")],a=Math.max(0,2*(v("#cl")+v("#cw"))*v("#ch")-v("#cd")*21-v("#cwn")*15),l=a*v("#cco")/p[1]*1.1;$("#cres").innerHTML='Paintable area <b>'+Math.round(a)+' sq ft</b><br>You need about <b>'+Math.ceil(l*2)/2+' litres</b> of '+p[0].toLowerCase()+' (10% wastage included)<br>Estimated cost <b>₹'+Math.round(l*p[2]).toLocaleString("en-IN")+'</b>';return[p[0],a,l,l*p[2]]}
$("#cf").addEventListener("input",rc);rc();
$("#cq").onclick=()=>{const r=rc();store.hist.push(r[0]+": "+Math.ceil(r[2])+" L, ₹"+Math.round(r[3]));lead("Calculator quote","Areva Paints quote request: "+r[0]+", "+Math.round(r[1])+" sq ft, about "+Math.ceil(r[2])+" litres.")};
const G=[["Living","Warm living room",0,8,"Sheen Pro"],["Living","Calm blue lounge",4,11,"White Delight"],["Bedroom","Orchid bedroom",6,13,"Dazzle Glow"],["Bedroom","Soft sand retreat",8,9,"Sheen Pro"],["Exterior","Terracotta facade",7,8,"Lumina LusterFinish"],["Exterior","Lagoon villa",3,11,"Zester Series"],["Kitchen","Mango kitchen",1,11,"White Delight"],["Kitchen","Olive and cream",12,13,"Sheen Pro"]];
let gf="All";
function drawG(){$("#gf").innerHTML=["All","Living","Bedroom","Exterior","Kitchen"].map(r=>'<button class="chip" data-f="'+r+'" aria-pressed="'+(r==gf)+'">'+r+'</button>').join("");$("#gg").innerHTML=G.map(g=>g[0]==gf||gf=="All"?'<button class="gi" data-g="'+g[2]+'" style="--a:'+C[g[2]][2]+';--b:'+C[g[3]][2]+'"><b>'+g[1]+'</b>'+C[g[2]][0]+' '+C[g[2]][1]+' with '+g[4]+'</button>':"").join("")}
const SV=[["Painting","Interior and exterior painting by trained crews."],["Colour consultation","Choose shades with an expert."],["Waterproofing","Roof and wall protection."],["Site visit","We inspect, measure and advise."]];
$("#sv").innerHTML=SV.map((s,i)=>'<div class="box"><h3>'+s[0]+'</h3><p>'+s[1]+'</p><button class="btn btn-line" data-v="'+i+'">Book this</button></div>').join("");
$("#bs").innerHTML=SV.map(s=>"<option>"+s[0]+"</option>").join("");
$("#bk").addEventListener("submit",e=>{e.preventDefault();const s=$("#bs").value,d=$("#bd").value;store.books.push(s+" on "+d);lead("Booking: "+s,"Areva Paints booking: "+s+" on "+d+"\nName: "+$("#bn").value+"\nPhone: "+$("#bp").value)});
const ST=["Karnataka","Maharashtra","Tamil Nadu","Andhra Pradesh"];
$("#st").innerHTML=ST.map(s=>'<button class="chip" data-st="'+s+'">'+s+'</button>').join("");
let role="Customer",signed=false;
function roles(){$("#roles").innerHTML=["Customer","Architect","Builder","Admin"].map(r=>'<button class="chip" data-r="'+r+'" aria-pressed="'+(r==role)+'">'+r+'</button>').join("")}
function dash(){const S=store.sv.map(k=>C.find(c=>c[1]===k)).filter(Boolean),ul=a=>a.length?"<ul>"+a.map(x=>"<li>"+x+"</li>").join("")+"</ul>":'<p class="note">None yet.</p>';let h="<h3>"+role+" dashboard</h3>";
if(role=="Admin")h+='<p>Leads <b>'+store.leads.length+'</b>, bookings <b>'+store.books.length+'</b>, saved colours <b>'+S.length+'</b></p><table><tr><th>Date</th><th>Type</th><th>Status</th></tr>'+store.leads.map((l,i)=>"<tr><td>"+l.d+"</td><td>"+l.t+'</td><td><select data-s="'+i+'">'+["New","Contacted","Quoted","Won","Lost"].map(s=>"<option"+(s==l.s?" selected":"")+">"+s+"</option>").join("")+"</select></td></tr>").join("")+"</table>";
else if(role=="Customer")h+="<p><b>Saved colours</b></p>"+ul(S.map(c=>c[0]+" ("+c[1]+")"))+"<p><b>Calculator history</b></p>"+ul(store.hist)+"<p><b>Bookings</b></p>"+ul(store.books);
else h+=ul(role=="Architect"?["Specification sheets","Colour libraries","Sample requests","Project registration"]:["Bulk pricing","Quote requests","Order history","Supply tracking"])+"<p class='note'>Requests sent this visit: "+store.leads.length+"</p>";
$("#dash").innerHTML=h+'<button class="btn btn-line" id="so">Sign out</button>'}
$("#lf").addEventListener("submit",e=>{e.preventDefault();signed=true;$("#lf").hidden=true;dash()});
$("#dash").addEventListener("change",e=>{if(e.target.dataset.s!=null)store.leads[+e.target.dataset.s].s=e.target.value});
$("#dash").addEventListener("click",e=>{if(e.target.id=="so"){signed=false;$("#dash").innerHTML="";$("#lf").hidden=false}});
$("#lx").onclick=()=>$("#lg").close();
document.addEventListener("click",e=>{const t=e.target.closest("[data-c],[data-h],[data-x],[data-g],[data-f],[data-v],[data-st],[data-r]");if(!t)return;const d=t.dataset;
if(d.c!=null){const c=C[d.c];paint(c[2],c[0]+" ("+c[1]+")")}
else if(d.h!=null){const k=C[d.h][1],i=store.sv.indexOf(k);i<0?store.sv.push(k):store.sv.splice(i,1);save();drawSw()}
else if(d.x)paint(d.x,d.x);
else if(d.g!=null){const c=C[+d.g];paint(c[2],c[0]+" ("+c[1]+")");$("#visualizer").scrollIntoView({behavior:"smooth"})}
else if(d.f){gf=d.f;drawG()}
else if(d.v!=null){$("#bs").selectedIndex=+d.v;$("#bk").scrollIntoView({behavior:"smooth",block:"center"})}
else if(d.st){$("#dl").innerHTML='<a class="btn btn-wa" target="_blank" rel="noopener" href="'+wa("Hello Areva Paints, please share the nearest dealer in "+d.st+".")+'">Dealer in '+d.st+'</a> <a class="btn btn-line" href="tel:+'+WA+'">Call</a>'}
else if(d.r){role=d.r;roles();if(signed)dash();if(!$("#lg").open)$("#lg").showModal()}});
paint(C[5][2],C[5][0]+" ("+C[5][1]+")");drawSw();drawG();roles();
$("#mq").innerHTML=[...C,...C].map(c=>'<span class="mp"><i style="background:'+c[2]+'"></i>'+c[0]+'</span>').join("");
