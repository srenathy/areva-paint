/* Core: banner slider, product categories and listing, product pop-up, enquiry form.
   Product and category data (cats, P) live here. */
const cats = [
 ["Interior Paints","🏠","Interior emulsion, luxury finishes and washable wall coatings.","#6c4cf5","#ff4fa3"],
 ["Exterior Paints","🌦️","Weather-resistant coatings and decorative finishes.","#ff7a18","#ffb800"],
 ["Waterproofing Solutions","💧","Roof coatings, moisture protection and waterproofing systems.","#0b7bd6","#2dd4e0"],
 ["Tile Adhesives","🧱","Adhesives for tile installation on suitable substrates.","#ff5a5f","#ff8a5f"],
 ["Sealants","🔧","Joint sealing and gap-filling for suitable applications.","#0fb5a2","#6ddb8c"],
 ["Wall Putty and Primers","🪣","Surface preparation, levelling and priming before painting.","#8a4cf5","#2d9cff"],
 ["Textures and Finishes","✨","Decorative wall textures, patterned finishes and exterior design.","#ff4fa3","#ffb800"],
 ["Construction Chemicals","🏗️","Bonding, surface repair and specialist construction products.","#1b6fd1","#6c4cf5"]];
const std = ["Applications","Key benefits","Surface preparation","Coverage","Packing sizes","Technical data sheet"];
const P = [
 ["Sheen Pro",0,"A decorative interior finish for smooth, good-looking walls.",std],
 ["Dazzle Glow",0,"A luxury-look interior finish for living spaces.",std],
 ["White Delight",0,"A clean white interior emulsion for everyday walls.",std],
 ["Lumina LusterFinish",1,"An exterior finish designed for weather exposure on suitable surfaces.",std],
 ["AquaSafe",2,"A waterproofing solution designed for suitable building surfaces and protection requirements.",["Applications","Key benefits","Surface preparation","Application method","Coverage","Packing","Technical data sheet"]],
 ["ROF-LEXA",2,"A roof protection coating for moisture and weather exposure.",std],
 ["Dry Lock",2,"A moisture protection product for suitable surfaces.",std],
 ["Pritex Shield",2,"A protective waterproofing product for building surfaces.",std],
 ["RedTape",3,"A tile adhesive for the installation applications specified for the product grade.",["Suitable tiles","Interior/exterior suitability","Substrate compatibility","Mixing instructions","Open time","Coverage","Bag size"]],
 ["Jointex Sealant",4,"A sealant for compatible joints and gaps, according to the specified product type.",["Suitable joints","Compatible materials","Movement capability","Application method","Curing time","Cartridge size"]],
 ["Renova Acrylic Putty",5,"An acrylic putty for preparing compatible wall surfaces for a smooth decorative finish.",["Suitable surfaces","Surface preparation","Application coats","Drying time","Sanding","Coverage","Packing sizes"]],
 ["7XT Universal Primer",5,"A primer for preparing surfaces before painting.",std],
 ["Zester Series",6,"A decorative finish collection to explore exterior colour and texture possibilities.",["Available finishes","Shade selection","Texture patterns","Application surfaces","Sample gallery","Product specifications"]],
 ["Areva Road Fix",7,"A repair mortar for roads and surface repair.",std]];
const $ = s => document.querySelector(s);
const wa = t => "https://wa.me/" + WA + "?text=" + encodeURIComponent(t);
const sel = { c: null };
function grad(c){ return "--a:" + c[3] + ";--b:" + c[4]; }
function renderTiles(){
  $("#tiles").innerHTML = cats.map((c,i)=>'<button class="tile" data-cat="'+i+'" aria-pressed="'+(sel.c===i)+'" style="'+grad(c)+'"><span class="em" aria-hidden="true">'+c[1]+'</span><span><h3>'+c[0]+'</h3><small>'+c[2]+'</small></span></button>').join("");
}
function renderGrid(){
  const list = P.map((p,i)=>[p,i]).filter(([p])=>sel.c===null||p[1]===sel.c);
  $("#listTitle").textContent = sel.c===null ? "All products" : cats[sel.c][0];
  $("#showAll").hidden = sel.c===null;
  $("#grid").innerHTML = list.map(([p,i])=>{const c=cats[p[1]];return '<article class="card" style="'+grad(c)+'"><div class="top" aria-hidden="true">'+p[0][0]+'</div><div class="bd"><span class="tag">'+c[0]+'</span><h4>'+p[0]+'</h4><p>'+p[2]+'</p><button class="btn btn-line" data-p="'+i+'">View details</button></div></article>'}).join("");
  renderTiles();
}
function pick(i, scroll){ sel.c = i; renderGrid(); if(scroll) $("#listTitle").scrollIntoView({behavior:"smooth",block:"start"}); }
document.addEventListener("click", e=>{
  const t = e.target.closest("[data-cat]"); if(t){ pick(+t.dataset.cat, true); if(t.closest(".slide")) location.hash="#products"; return; }
  const b = e.target.closest("[data-p]"); if(b) openP(+b.dataset.p);
});
$("#showAll").onclick = ()=>pick(null,false);
const dlg = $("#dlg"); let cur = 0;
function openP(i){
  cur=i; const p=P[i], c=cats[p[1]];
  $("#dTop").style.cssText = grad(c); $("#dName").textContent=p[0]; $("#dCat").textContent="Category: "+c[0]; $("#dDesc").textContent=p[2];
  $("#dSec").innerHTML = p[3].map(s=>"<li>"+s+"</li>").join("");
  $("#dWa").href = wa("Hello Areva Paints, I would like details about "+p[0]+".");
  dlg.showModal();
}
$("#x").onclick = ()=>dlg.close();
dlg.addEventListener("click", e=>{ if(e.target===dlg) dlg.close(); });
$("#dEnq").onclick = ()=>{ dlg.close(); $("#pr").value=P[cur][0]; $("#topic").value="Request a quotation"; $("#contact").scrollIntoView({behavior:"smooth"}); };
$("#help").innerHTML = [...$("#topic").options].map((o,i)=>'<button type="button" data-t="'+i+'">'+o.text+'</button>').join("");
$("#help").addEventListener("click", e=>{ const b=e.target.closest("[data-t]"); if(b){ $("#topic").selectedIndex=+b.dataset.t; $("#nm").focus(); }});
$("#form").addEventListener("submit", e=>{ e.preventDefault();
  const m = "Areva Paints enquiry: "+$("#topic").value+"\nName: "+$("#nm").value+"\nPhone: "+$("#ph").value+($("#pr").value?"\nProduct: "+$("#pr").value:"")+($("#ms").value?"\nMessage: "+$("#ms").value:"");
  window.open(wa(m), "_blank", "noopener"); });
$("#fab").href = wa("Hello Areva Paints, I have an enquiry.");
renderGrid();
// right-to-left auto slider (loops forward via a cloned first slide)
const track=$("#track"), n=track.children.length, dots=$("#dots");
track.appendChild(track.children[0].cloneNode(true));
let idx=0, timer;
for(let i=0;i<n;i++){ const d=document.createElement("button"); d.setAttribute("aria-label","Slide "+(i+1)); d.onclick=()=>{go(i);restart()}; dots.appendChild(d); }
function mark(){ [...dots.children].forEach((d,i)=>d.setAttribute("aria-current", i===idx%n)); }
function go(i){ idx=i; track.style.transition=""; track.style.transform="translateX(-"+idx*100+"%)"; mark(); }
function next(){ idx++; track.style.transform="translateX(-"+idx*100+"%)"; mark(); }
track.addEventListener("transitionend", ()=>{ if(idx===n){ track.style.transition="none"; idx=0; track.style.transform="translateX(0)"; mark(); void track.offsetWidth; track.style.transition=""; }});
function restart(){ clearInterval(timer); if(!matchMedia("(prefers-reduced-motion:reduce)").matches) timer=setInterval(next,5500); }
const sl=document.querySelector(".slider"); sl.addEventListener("mouseenter",()=>clearInterval(timer)); sl.addEventListener("mouseleave",restart);
mark(); restart();
