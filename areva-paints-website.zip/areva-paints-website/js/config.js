/* Site settings. Edit these before publishing. */
const WA = "910000000000"; // replace with the real WhatsApp number (country code + number)
