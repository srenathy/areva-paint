# Areva Paints Website

A colourful, mobile-first website for Areva Paints. It is a static front end (plain HTML, CSS and JavaScript, no build step), so it runs anywhere and deploys to GitHub Pages for free.

## Features

- Home banner that slides right to left, colour ticker and a **bubble pop game** (bubbles burst into colourful dots)
- **Products**: 8 categories, product list and detail pop-up (AquaSafe, RedTape, Jointex, Renova Putty, Zester Series and more)
- **Colour visualizer**: 5 ready-made rooms (living room, bedroom, kitchen, house front, apartment) **or upload your own home photo**, tap a wall to paint it, before/after slider, undo, and **print a before/after sheet**
- Colour search by name or code, saved colours (wishlist), "goes well with" suggestions, shareable palette
- **Paint calculator** with a WhatsApp quote button
- Inspiration gallery, services with booking form, dealer finder by state
- Architect and builder portal sections, role-based demo login and dashboards (customer, architect, builder, admin leads table)
- About us, certifications and enquiry form (quotation, dealer, technical support, warranty, complaint)
- Automatic dark mode and reduced-motion support

## Project structure

```
index.html          Page markup
css/styles.css      All styles (colour tokens are at the top, in :root)
js/config.js        Site settings: WhatsApp number
js/main.js          Banner slider, product categories and products, enquiry form
js/features.js      Colours, calculator, gallery, services, dealers, login and dashboards
js/bubbles.js       Bubble pop game
js/painter.js       Room visualizer, photo upload, wall painting, print sheet
.github/workflows/  GitHub Pages deployment
```

The scripts share globals and must load in the order shown in `index.html`.

## Run locally

```bash
npm start
# or, without Node:
python3 -m http.server 8000
```

Then open the address shown (for example http://localhost:3000 or http://localhost:8000).

## Publish to GitHub

```bash
cd areva-paints-website
git init
git add .
git commit -m "Initial commit: Areva Paints website"
git branch -M main
git remote add origin https://github.com/<your-username>/areva-paints-website.git
git push -u origin main
```

Then in the repository go to **Settings → Pages → Build and deployment → Source: GitHub Actions**. Every push to `main` redeploys the site. The address will be `https://<your-username>.github.io/areva-paints-website/`.

## Before going live

1. **WhatsApp number**: set `WA` in `js/config.js` (country code plus number, no plus sign or spaces, for example `919876543210`). The enquiry form, booking form, calculator quote, dealer finder and floating button all use it.
2. **Contact details**: add office and factory addresses, phone, email and map in the Contact section of `index.html`.
3. **Sample content to replace**: shade names and codes and calculator rates and coverage (`js/features.js`), testimonials and blog titles (`index.html`), product descriptions (`js/main.js`, from your technical data sheets), and the certifications section once certificates are verified.
4. **Photos**: products currently show colour blocks. Real product photos and project images can be added to an `images/` folder.
5. **Default rooms** are drawn illustrations (`SC` in `js/painter.js`). Real room photos can replace them.

## Known limits

- **Wall painting** picks areas by colour similarity, not by recognising walls. Uneven light or patterned walls may need several taps or a higher "wall selection range".
- **Login and dashboards are a demo**. There are no real accounts, and data lasts only for the visit (saved colours stay in the visitor's browser).
- **Forms open WhatsApp** and do not store anything on a server.
- **Not built yet**: online payments, photo-based AI wall detection, a real admin CMS and database, order history and a map-based store locator.

## Suggested next step

For real accounts, leads, bookings and an admin panel, add a backend. A good fit is Next.js with Supabase (auth, PostgreSQL, storage) and Razorpay for payments. The current files can become the starting components.
